# Adafruit_AMG88xx

Arduino code for the Adafruit AMG8833 breakout.
https://learn.adafruit.com/adafruit-amg8833-8x8-ir-sensor/overview
